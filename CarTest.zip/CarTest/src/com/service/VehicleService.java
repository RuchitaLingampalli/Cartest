package com.service;

import java.util.Scanner;

import com.bean.Vehicle;
import com.dao.VehicleDAOImpl;
import com.ui.VehicleView;


interface vehicleserviceimpl{
	public void addVehicleDetails(Vehicle v);
	public 	Vehicle getVehicleDetails(int id);
}

public class VehicleService implements vehicleserviceimpl {
	Scanner sc=new Scanner(System.in);
	Vehicle v=new Vehicle(); 
VehicleDAOImpl vd=new VehicleDAOImpl();
public void addVehicleDetails(Vehicle v) {
	vd.addVehicle(v);
	
	// TODO Auto-generated method stub
	
}
public Vehicle getVehicleDetails(  int vehicleId) {
	// TODO Auto-generated method stub
	v=vd.getVehicleDetails( vehicleId);
	return v;
}


}
