package com.service;

import java.util.HashMap;
import java.util.Scanner;

import com.bean.Distributor;
import com.bean.Vehicle;
import com.dao.VehicleDAOImpl;
import com.ui.VehicleView;

interface XYZShoppeService{
	public void addVehicleDistributor(HashMap<Vehicle,Distributor> hm);
	public HashMap<Vehicle,Distributor>getDistributor();
	public HashMap<Vehicle,Distributor>getVehicle();
	
}
public class XYZShoppeServiceImpl implements XYZShoppeService {

	@Override
	public void addVehicleDistributor(HashMap<Vehicle, Distributor> hm) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public HashMap<Vehicle, Distributor> getDistributor() {
		return null;
	}

	@Override
	public HashMap<Vehicle, Distributor> getVehicle() {
		// TODO Auto-generated method stub
		return null;
	}


}
