package com.service;

import java.util.Scanner;

import com.bean.Distributor;
import com.bean.Vehicle;
import com.dao.VehicleDAOImpl;
import com.dao.DistributorDAOImpl;

interface DistributorService{
	public void addDistributorService(Distributor distributor);
	public Distributor getDistributorDetailsService(int distributorId);
}


public class DistributorServiceImpl implements DistributorService{
	
	Scanner sc=new Scanner(System.in);
	Distributor d=new Distributor(); 
DistributorDAOImpl dd=new DistributorDAOImpl();


	@Override
	public void addDistributorService(Distributor D) {
		dd.addDistributor(d);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public Distributor getDistributorDetailsService(int distributorId) {
		
		
		d=dd.getDistributorDetails( distributorId);
		return d;
		// TODO Auto-generated method stub
		
	}

}
