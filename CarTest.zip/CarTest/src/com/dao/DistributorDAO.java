package com.dao;

import com.bean.Distributor;

public interface DistributorDAO{
	public void addDistributor(Distributor distributor);
	public Distributor getDistributorDetails(int distributorId);
}
