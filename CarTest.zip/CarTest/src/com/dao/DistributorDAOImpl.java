package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.bean.Distributor;
//import com.bean.Vehicle;


public class DistributorDAOImpl implements DistributorDAO {
	List<Distributor> al=new ArrayList<Distributor>(0);
	Distributor d=new Distributor();

	@Override
	public void addDistributor(Distributor distributor) {
		
		al.add(distributor.getDistributorId(),distributor);
		System.out.println("Added");
		
	}

	@Override
	public Distributor getDistributorDetails(int id) {
		
		Distributor d=(Distributor) al.get(0);
		System.out.println(d);
		return d;
		
		
		// TODO Auto-generated method stub
		
	}
	

	
	}

	


