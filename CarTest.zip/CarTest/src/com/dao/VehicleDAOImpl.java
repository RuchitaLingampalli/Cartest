package com.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Scanner;

import com.bean.Vehicle;
import com.ui.VehicleView;


 public  class VehicleDAOImpl implements VehicleDAO {
	 HashMap<Integer,Vehicle> hm=new HashMap<Integer,Vehicle>();
     Vehicle v=new Vehicle();
	@Override
	public void addVehicle(Vehicle v) {
         try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","India123");
			//Scanner sc=new Scanner(System.in);
			PreparedStatement stmt=con.prepareStatement("insert into Vehicle values(?,?,?)");
			stmt.setString(1, v.getModelName());
			stmt.setInt(2,v.getVehicleId());
			stmt.setDouble(3, v.getPrice());
			stmt.executeUpdate();
			System.out.println("ADDED");
			con.close();
			//sc.close();
		}	catch(Exception e)
		{
			System.out.println(e);
		}
		
	
		
		
		
		//hm.put(vehicle.getVehicleId(),vehicle);
		//System.out.println("ADDED");
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public Vehicle getVehicleDetails(int id) {
		
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","India123");
			Statement stmt=con.createStatement();
			//Scanner sc=new Scanner(System.in);
			//System.out.println("Enter id:");
			//id=sc.nextInt();
			ResultSet rs=stmt.executeQuery("select * from Vehicle where vehicleId=" +id + " ");
			while(rs.next()) {
			System.out.println(rs.getString(1)+ " "+rs.getInt(2)+ " "+rs.getInt(3));
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return v;
			
		
		//Vehicle v=hm.get(id);
		//System.out.println(v);
		//return v;
		
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		return "VehicleDAOImpl [v=" + v + "]";
	}
	 

	}





	


 





 
 
 
 
 
 