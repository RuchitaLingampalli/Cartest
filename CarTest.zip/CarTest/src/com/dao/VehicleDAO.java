package com.dao;

import com.bean.Vehicle;
import com.ui.VehicleView;

public interface VehicleDAO {
	
		public void addVehicle(Vehicle vehicle);
		public Vehicle getVehicleDetails(int  Vehicleid);
	}

