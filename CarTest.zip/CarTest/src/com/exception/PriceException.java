package com.exception;

public class PriceException extends RuntimeException {
 public PriceException() {
	 
 }
 public PriceException(String s) {
	 System.out.println(s);
 }
}
