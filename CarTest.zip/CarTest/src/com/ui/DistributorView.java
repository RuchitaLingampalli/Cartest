package com.ui;

import java.util.Random;
import java.util.Scanner;

import com.bean.Distributor;
import com.service.DistributorServiceImpl;
import com.service.VehicleService;

public class DistributorView {	
	Scanner sc=new Scanner (System.in); 
	VehicleService s=new VehicleService();
	DistributorServiceImpl ds=new DistributorServiceImpl();
	Distributor d;
	Random rObj=new Random();
	public void getDistributorDetails() {
			System.out.println("Enter distributor Name:");
			String st=sc.next();
			System.out.println("Distributor name is:"+st);

			System.out.println("Enter address:");
			String ad=sc.next();
			System.out.println("Address is"+ad);

			System.out.println("Enter mobile no:");
			String mb=sc.next();
			System.out.println("Mobile no is:"+mb);
			
			System.out.println("Distributor Details ADDED.");
			int distributorId=rObj.nextInt(100);
			System.out.println("distributorId is:"+distributorId);

			d=new Distributor(distributorId,st,ad,mb);
			ds.addDistributorService(d);
			
			System.out.println(d);
			
		}
	@Override
	public String toString() {
		return "DistributorView [d=" + d + "]";
	}
		

	
public void getDDetails() {
	System.out.println("Enter a Distributor ID:");
	int id=sc.nextInt();
	ds.getDistributorDetailsService(id);
}
}