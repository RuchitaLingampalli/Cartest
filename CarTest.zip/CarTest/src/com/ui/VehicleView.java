package com.ui;

import java.util.Random;
import java.util.Scanner;

import com.bean.Vehicle;
import com.bean.Vehicle.CarType;
import com.service.VehicleService;

public class VehicleView {
	Scanner sc=new Scanner (System.in);
	Vehicle v;
	//VehicleView v1;
	Random rObj=new Random();
	
	VehicleService s=new VehicleService();
	public VehicleView() {
		
	}
	public VehicleView(int vehicleId) {
		// TODO Auto-generated constructor stub
	}
	public void getVehicleDetails() {
		System.out.println("Enter modelName:");
		String modelname=sc.next();
		System.out.println("Model is:" +modelname);
		
		System.out.println("Enter price:");
		int price=pricecheck(sc.nextInt());
		
		//System.out.println("Price is:"+price);
		
		System.out.println("Car Type:");
		String type=sc.next();
		System.out.println("CarType="+ type);
		CarType ct=CarType.valueOf(type);

		System.out.println("Vehicle added successfully");
		int vehicleId=rObj.nextInt(300);
		System.out.println("vehicle id is:"+vehicleId);
		
		 v=new Vehicle(vehicleId,modelname,price,ct);
		//v1=new VehicleView(vehicleId);
		
		s.addVehicleDetails(v);
	
		System.out.println(v);
	}
	
@Override
	public String toString() {
		return "VehicleView [v=" + v + "]";
	}

public int pricecheck(int price) {
	try {
		if(price<500000)
		{
			System.out.println("PriceException");
		}
	}catch(Exception e) {
		System.out.println(e);
	}
	return price;
}

public void getDetails() {
	System.out.println("Enter a Vehicle ID:");
	int id=sc.nextInt();
	s.getVehicleDetails(id);
}

	
}
	
	
