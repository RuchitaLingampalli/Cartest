package com.ui;

import java.util.*;

public class Main {
 
	public static void main(String args[]) {
		
		char choice;
		int ch;
		VehicleView vv=new VehicleView();
		DistributorView dv=new DistributorView();
		Scanner sc=new Scanner(System.in);
		do {
		System.out.println("Enter your choice:");
		System.out.println("*****************\n 1.Add a vehicle , \n 2.Retrieve a vehicle, \n 3.Add Distributor Details, \n 4.Retrieve Distributor Details ,\n 5.exit****************");
		
		System.out.println("Enter your choice:");
		ch=sc.nextInt();
		
		switch(ch) {
		case 1 :
			vv.getVehicleDetails();
			break;
			
		case 2 :
			vv.getDetails();
			break;
			
		case 3 :
			dv.getDistributorDetails();
			break;
			
		case 4 :
			dv.getDDetails();
			break;
			
		case  5 :System.out.println("exit");
		        System.exit(0);
			
		}
			System.out.println("do you want to continue(y/n)...?:");
		choice =sc.next().charAt(0);
		if (choice == 'y'|| choice =='Y')
			continue;
		else {
			
			System.out.println("Thank you");
			System.exit(0);
				
		}
		
		}while(ch!=4);
		sc.close();
	
	}
	
	
}
