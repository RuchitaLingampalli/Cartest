package com.bean;

public class Vehicle {

	
	private int vehicleId;
	private String modelName;
	private double price;
	CarType type;
	
	public enum CarType{
		hatchback,Sedan,MPV,SUV;
	}
	
	public Vehicle() {

	}
	
	public Vehicle(int vehicleId,String modelName,double price ,CarType type) {
		this.modelName=modelName;
		this.price=price;
		this.type=type;
		this.vehicleId=vehicleId;
		}

	
	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", modelName=" + modelName + ", price=" + price + ", type=" + type
				+ "]";
	}

	public Vehicle(int vehicleId,String modelName,double price) {
		this.vehicleId=vehicleId;
		this.modelName=modelName;
		this.price=price;
	}

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public CarType getType() {
		return type;
	}

	public void setType(CarType type) {
		this.type = type;
	}


	
}
