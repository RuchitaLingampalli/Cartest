package com.bean;

public class VehicleDistributor {
 Vehicle vehicle;
 Distributor distributor;
 
 public VehicleDistributor(Vehicle vehicle,Distributor distributor) {
	 this.vehicle=vehicle;
	 this.distributor=distributor;
	 
 }

public Vehicle getVehicle() {
	return vehicle;
}

public void setVehicle(Vehicle vehicle) {
	this.vehicle = vehicle;
}

public Distributor getDistributor() {
	return distributor;
}

public void setDistributor(Distributor distributor) {
	this.distributor = distributor;
}
 
 
 
}
