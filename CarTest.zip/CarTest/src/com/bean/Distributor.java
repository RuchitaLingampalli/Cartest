package com.bean;

public class Distributor {

	private int distributorId;
	private String name;
	private String mobileNo;
	private String address;
	
	public Distributor() {
		
	}
	
public Distributor(String name,String mobileNo,String address) {
		
		
		this.name=name;
		this.mobileNo=mobileNo;
		this.address=address;
	}

	
	
	public Distributor(int distributorId,String name,String mobileNo,String address) {
		
		this.distributorId=distributorId;
		this.name=name;
		this.mobileNo=mobileNo;
		this.address=address;
	}


	@Override
	public String toString() {
		return "Distributor [distributorId=" + distributorId + ", name=" + name + ", mobileNo=" + mobileNo
				+ ", address=" + address + "]";
	}

	public int getDistributorId() {
		return distributorId;
	}


	public void setDistributorId(int distributorId) {
		this.distributorId = distributorId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}

	
	
	
}
